<div class="email">
   <P>This is your OTP: </P>
   <h1>{{$otp}}</h1>
</div>