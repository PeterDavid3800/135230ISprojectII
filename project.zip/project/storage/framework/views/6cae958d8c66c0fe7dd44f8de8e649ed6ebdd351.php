<div class="email">
   <P>This is your OTP: </P>
   <h1><?php echo e($otp); ?></h1>
</div><?php /**PATH C:\Users\Peter David\OneDrive\Documents\Github\135230ISprojectII\project\resources\views/emails/sendOtp.blade.php ENDPATH**/ ?>